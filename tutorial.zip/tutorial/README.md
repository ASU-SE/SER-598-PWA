# What is this tutorial folder?

* This folder contains all the resources for tutorial that will help create a PWA
* flashcardWithoutPWAForTutorial is an initialized Springboot application that has the flashcard code minus PWA implementation
* The follow along tutorial helps the user to work on this application and create a fully functional flash card PWA application

* The videoTutorial.html has the list of all the video tutorials.
* These tutorials start with the introduction and guide the user with step by step implemention of the components of PWA
* These are hosted on youtube (by respective team members)
* You can check the videoTutorial.html by opening the file videoTutorial.html in chrome (Right click on the file and open in chrome browser (or any browser))

* The writeupTutorial.html has the entire tutorial step by step process to build the application
* You can check the writeup by opening the file writeupTutorial.html in chrome (Right click on the file and open in chrome browser (or any browser))

